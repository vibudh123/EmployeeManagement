import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSortModule } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatSortModule,
    MatTableDataSource
  ],
  exports: [
    CommonModule,
    MatSortModule,
    MatTableDataSource
  ]
})
export class MaterialModule { }
