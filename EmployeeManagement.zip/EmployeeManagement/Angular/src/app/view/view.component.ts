import { Component, OnInit, ViewChild } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { Observable } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table'; 
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import * as XLSX from 'xlsx'; 


@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  employee: Employee = new Employee();
  show:boolean=false;
  manager = [
    {name: "Mr. Manjunath Gowda"},
    {name: "Mr. Rakesh Kumar"},
    {name: "Mr. Suresh Kumar"},
    {name: "Mrs. Satya Devi"}
  ];
  
  employees: Observable<Employee[]>;
  public displayedColumns = ['firstName', 'emailId', 'skillSet','projectName', 'Details'];
  public dataSource = new MatTableDataSource<Employee>();
  
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private employeeService: EmployeeService,
    private router: Router) {}

  ngOnInit() {
    
    this.getAllOwners();
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
 }
 fileName= 'ExcelSheet.xlsx';  

 exportexcel(): void 
     {
        /* table id is passed over here */   
        let element = document.getElementById('excel-table'); 
        const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
 
        /* generate workbook and add the worksheet */
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
 
        /* save to file */
        XLSX.writeFile(wb, this.fileName);
       
     }
  
    public getAllOwners = () => {
      this.employeeService.getData('employees')
      .subscribe(res => {
        this.dataSource.data = res as Employee[];
      })
    }
    public doFilter = (value: string) => {
      this.show=true;
      this.dataSource.filter = value.trim().toLocaleLowerCase();
    }
  

  deleteEmployee(id: number) {
    this.employeeService.deleteEmployee(id)
      .subscribe(
        data => {
          console.log(data);
          this.getAllOwners();
        },
        error => console.log(error));
  }

  employeeDetails(id: number){
    this.router.navigate(['details', id]);
  }

  updateEmployee(id: number){
    this.router.navigate(['update', id]);
  }

}
