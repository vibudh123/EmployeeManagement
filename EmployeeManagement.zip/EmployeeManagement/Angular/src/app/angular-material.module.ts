import { NgModule } from '@angular/core';

import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import{MatSortModule} from '@angular/material/sort';
import { RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ViewComponent } from './view/view.component';


const routes: Routes = [
   { path: 'view', component: ViewComponent }
 ];
@NgModule({
   imports: [
      MatTableModule,
      MatPaginatorModule,
      MatSortModule,
      CommonModule,
      MaterialModule,
    RouterModule.forChild(routes)
   ],
   exports: [
      MatTableModule,
      MatPaginatorModule,
      RouterModule,
      MatSortModule
   ]
})

export class MaterialModule { }