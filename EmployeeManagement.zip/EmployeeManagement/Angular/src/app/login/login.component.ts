import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { Admin } from '../admin';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  admin:Admin=new Admin("","");
  message: any;
  val:boolean;
  constructor(private service:EmployeeService,private router:Router) { }
  check : "";

  ngOnInit(): void {
  }

  doLogin() {
    let resp = this.service.login(this.admin);
    // resp.subscribe(data => 
    //   {
    //   console.log(data.valueOf())
    //   if (data.valueOf()) {
    //     console.log('login success');
    //     this.router.navigate(['/registration']);
    //   } 
    //   else if(data.valueOf()!=true) {
    //     console.log('Login failed');
    //   }
    // });
    resp.subscribe(data => {
      console.log(data)
      this.message = data;
    //  this.router.navigate(["/registration"])
    });
    this.val = (this.message==this.check);
    if(this.val==false)
    {
      
      this.router.navigate(['/registration'])
      // this.router.routeReuseStrategy.shouldReuseRoute = function () {
      //     return false;
      //   };
      //   this.router.navigate(['/registration'], {
      //     queryParams: {refresh: new Date().getTime()}
      //  });
      
    }
    else{
      alert("Incorrect username/password")
      this.router.navigate(['/login'])
    //   this.router.routeReuseStrategy.shouldReuseRoute = function () {
    //     return false;
    //   };
    //   this.router.navigate(['/login'], {
    //     queryParams: {refresh: new Date().getTime()}
    //  });
    }
  }
  
}
