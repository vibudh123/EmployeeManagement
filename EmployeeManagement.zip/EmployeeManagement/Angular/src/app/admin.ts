export class Admin{
        userName:string;
        password:any;
    constructor(
        userName:string,
        password:any
    ){
        this.userName=userName;
        this.password=password;
    }
}