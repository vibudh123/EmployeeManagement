export class Employee{
    id: number;
    firstName: string;
    lastName: string;
    emailId: string;
    role:string;
    projectName:string;
    managerName:string;
    skillSet:string;
    jobHistory:string;
    active: boolean;
}
