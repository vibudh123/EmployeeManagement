import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import * as XLSX from 'xlsx'; 
import { HttpEventType, HttpResponse, HttpClient, HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  employee: Employee = new Employee();
  emp: Employee[]=[];
  submitted = false;
  show:boolean=false;
  employees: Observable<Employee[]>;
  fileName= 'ExcelSheet.xlsx';  
  myFiles:string [] = [];
  sMsg:string = '';
  public displayedColumns = ['firstName', 'lastName', 'emailId', 'role', 'projectName','managerName','Delete','Update'
];
  public dataSource = new MatTableDataSource<Employee>();
  
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  title = 'File-Upload-Save';
selectedFiles: FileList;
currentFileUpload: File;
progress: { percentage: number } = { percentage: 0 };
selectedFile = null;
SERVER_URL = "http://localhost:8070/employees/file";
  uploadForm: FormGroup; 
  
  manager = [
    {name: "Mr. Manjunath Gowda"},
    {name: "Mr. Rakesh Kumar"},
    {name: "Mr. Suresh Kumar"},
    {name: "Mrs. Satya Devi"}
  ];
  constructor(private employeeService: EmployeeService,
    private router: Router,private formBuilder: FormBuilder, private httpClient: HttpClient) { }

  ngOnInit() {
    this.getAllOwners();
    this.uploadForm = this.formBuilder.group({
      profile: ['']
    });
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
 }
 

 exportexcel(): void 
     {
        /* table id is passed over here */   
        let element = document.getElementById('excel-table'); 
        const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
 
        /* generate workbook and add the worksheet */
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
 
        /* save to file */
        XLSX.writeFile(wb, this.fileName);
       
     }

     showIt(){
      this.show=true;
    }
    NoshowIt(){
      this.show=true;
    }
 public getAllOwners = () => {
      this.employeeService.getData('employees')
      .subscribe(res => {
        this.dataSource.data = res as Employee[];
      })
    }
  public doFilter = (value: string) => {
      this.dataSource.filter = value.trim().toLocaleLowerCase();
    }
  reloadData() {
    this.employees = this.employeeService.getEmployeesList();
    this.router.navigate(['/registration']);
  }
  

  getFileDetails (files) {
    console.log (files.target.files);
    this.selectedFiles = files.target.files;
    for (var i = 0; i < files.target.files.length; i++) { 
      this.myFiles.push(files.target.files[i]);
    }
  }

  uploadFiles () {
    const frmData = new FormData();
    
    for (var i = 0; i < this.myFiles.length; i++) { 
      frmData.append("file", this.myFiles[i]);
    }
    
    this.httpClient.post(this.SERVER_URL, frmData).subscribe(
      data => {
        // SHOW A MESSAGE RECEIVED FROM THE WEB API.
        this.sMsg = data as string;
        console.log (this.sMsg);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);    // Show error, if any.
      }
    );
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
    this.router.navigate(['/registration'], {
      queryParams: {refresh: new Date().getTime()}
   });
  }
 
  deleteEmployee(id: number) {
    this.employeeService.deleteEmployee(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
          return false;
        };
        this.router.navigate(['/registration'], {
          queryParams: {refresh: new Date().getTime()}
       });
  }

  employeeDetails(id: number){
    this.router.navigate(['details', id]);
  }

  updateEmployee(id: number){
    this.router.navigate(['update', id]);
  }
  newEmployee(): void {
    this.submitted = false;
    this.employee = new Employee();
  }

  save() {
    this.employeeService.createEmployee(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    alert("User Successfull Added!");
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
    return false;
  };
    this.router.navigate(['/registration'], {
      queryParams: {refresh: new Date().getTime()}
   });
  }
  
  
}