import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { IfStmt } from '@angular/compiler';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  id: number;
  employee: Employee;

  constructor(private route: ActivatedRoute,private router: Router,
    private employeeService: EmployeeService) { }

  ngOnInit() {
    this.employee = new Employee();

    this.id = this.route.snapshot.params['id'];
    
    this.employeeService.getEmployee(this.id)
      .subscribe(data => {
        console.log(data)
        this.employee = data;
      }, error => console.log(error));
  }

  updateEmployee() {
    this.employeeService.updateEmployee(this.id, this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
    this.gotoList();
  }

  onSubmit() {
    this.updateEmployee();    
  }

  gotoList() {
    this.router.navigate(['/registration']);
  }
  // registerForm: FormGroup;
  // id: number;
  // employee: Employee= new Employee(0,"","","","");

  // constructor(private route: ActivatedRoute,private router: Router,private employeeService: EmployeeService,private formBuilder: FormBuilder) {
    
  //    }

  // ngOnInit() {
    
  //     this.registerForm = this.formBuilder.group({
  //       userName: ['', Validators.required, Validators.minLength(2),Validators.maxLength(10)],
  //       designation: ['', Validators.required],
  //       project: ['', [Validators.required, Validators.minLength(2),Validators.maxLength(10)]],
  //       password: ['', [Validators.required, Validators.minLength(6)]]
  //    });
    
  //   this.route.paramMap.subscribe(params => {
  //     const empId=+params.get('id');
  //     if(empId){
  //       this.getEmployee(empId);
  //     }

  //   });
  //   this.employeeService.getUserById(this.id)
  //     .subscribe(data => {
  //       console.log(data)
  //       this.employee = data;
  //     }, error => console.log(error));
  // }

  // getEmployee(id:number){
  //   this.employeeService.getUserById(id).subscribe(
  //   (employee:Employee) =>this.editEmployee(employee),
  //   (err:any) => console.log(err));
  // }

  // editEmployee(employee: Employee){
  //   this.registerForm.patchValue({
  //     userName:employee.userName,
  //     password:employee.password,
  //     designation:employee.designation,
  //     project:employee.project

  //   });
  // }
  // updateEmployee() {
  //   this.employeeService.updateEmployee(this.id, this.employee)
  //     .subscribe(data => console.log(data), error => console.log(error));
  //   this.employee = new Employee(this.employee.id,"","","","");
  //   this.gotoList();
  // }

  // onSubmit() {
  //   this.updateEmployee();    
  // }

  // gotoList() {
  //   this.router.navigate(['/view']);
  // }

}
