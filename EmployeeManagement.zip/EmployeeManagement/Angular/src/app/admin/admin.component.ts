import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Admin } from '../admin';
import { conditionallyCreateMapObjectLiteral } from '@angular/compiler/src/render3/view/util';
import { FormGroup, FormBuilder, Validators,FormControl, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  admin: Admin = new Admin("","");
  message:string;
  val:boolean;
  check : Object = undefined;
  submitted = false;
  registerForm: FormGroup;

  constructor(private service:EmployeeService,private router: Router,private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      userName: ['',[Validators.required]],
      password: ['', [Validators.required,Validators.pattern('(?=.*[A-Za-z])(?=.*[0-9])(?=.*[$@$!#^~%*?&,.<>"\'\\;:\{\\\}\\\[\\\]\\\|\\\+\\\-\\\=\\\_\\\)\\\(\\\)\\\`\\\/\\\\\\]])[A-Za-z0-9\d$@].{7,}'), Validators.minLength(6)]]

    } );
  }
  onSubmit() {
    this.submitted = true;
    
  
    this.registerNow(); 
   
  }
  
  public registerNow(){
    let resp =this.service.addAdminUser(this.admin);
     resp.subscribe((data) => console.log(data) , error => console.log(error));
     this.val = (this.message==this.check);
     console.log(this.val);  
     if(this.val==true){
        alert("User successfully registered");
        this.router.navigate(['/login'])}
      
      else{
        alert("User already exists");
        this.router.navigate(['/admin'])
      }
   
  }
}
