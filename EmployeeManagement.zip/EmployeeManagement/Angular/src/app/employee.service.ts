import { Injectable, ViewChild } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { environment } from 'src/environments/environment';
import { Admin } from './admin';
import * as XLSX from 'xlsx'; 

const HttpUploadOptions = {
  headers: new HttpHeaders({ "Content-Type": "multipart/form-data" })
}

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  
  private baseUrl = 'http://localhost:8070/employees';
  SERVER_URL = "http://localhost:8070/employees/file";

  constructor(private http:HttpClient) { }
  public getData = (route: string) => {
    return this.http.get(this.createCompleteRoute(route, 'http://localhost:8070'));
  }
  private createCompleteRoute = (route: string, envAddress: string) => {
    return `${envAddress}/${route}`;
  }
  private generateHeaders = () => {
    return {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }
  }
  
  
  // public login(admin): Observable<Boolean>{
  //     
  //     return this.http.post<Boolean>("http://localhost:8070/login",admin,{responseType: 'text' as 'json'});
  // }
  public login(admin): Observable<Object>{
      
      return this.http.post<Admin>("http://localhost:8070/login",admin,{responseType: 'text' as 'json'});
  }
  public addUser(user){
    return this.http.post("http://localhost:8070/addUser",user,{responseType:'text' as 'json'});
  }

  public addAdminUser(user){
    return this.http.post("http://localhost:8070/addAdminUser",user,{responseType:'text' as 'json'});
  }
  getEmployee(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createEmployee(employee: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, employee);
  }

  updateEmployee(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteEmployee(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getEmployeesList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
  pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
    
    const data: FormData = new FormData();
    data.append('file', file);
    const newRequest = new HttpRequest('POST', 'http://localhost:8070/file', data, {
    reportProgress: true,
    responseType: 'text'
    });
    return this.http.post<any>(this.SERVER_URL, file,HttpUploadOptions);
    // return this.http.request(newRequest);
    }
  

}
