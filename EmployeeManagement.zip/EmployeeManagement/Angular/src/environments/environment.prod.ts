export const environment = {
  production: true,
  urlAddress: 'http://www.ang-material-account-owner.com'
};
