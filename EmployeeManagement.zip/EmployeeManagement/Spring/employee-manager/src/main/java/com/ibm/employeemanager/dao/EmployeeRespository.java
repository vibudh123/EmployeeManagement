package com.ibm.employeemanager.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.employeemanager.bean.Employee;

public interface EmployeeRespository extends CrudRepository<Employee, Long>{

	void deleteById(String id);
	
	
	@Modifying
	@Transactional
	@Query(value = "update employee set skill_set=:uSkill where id=:uId", nativeQuery = true)
	public Employee updateSkill(@Param("uId") long id, @Param(value = "uSkill") String skillSet);
//	
//	@Modifying
//	@Transactional
//	@Query(value = "update employee set designation=:uDesignation where id=:uId", nativeQuery = true)
//	public void updateDesignation(@Param("uId") int id, @Param(value = "uDesignation") String designation);
//	
//	@Modifying
//	@Transactional
//	@Query(value = "update employee set password=:uPassword  where id=:uId", nativeQuery = true)
//	public void updatePassword( @Param(value="uId") int id, @Param(value = "uPassword") String password);
	
	
}
