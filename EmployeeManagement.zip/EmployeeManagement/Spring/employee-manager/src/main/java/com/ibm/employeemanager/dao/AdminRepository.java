package com.ibm.employeemanager.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.ibm.employeemanager.bean.Admin;

public interface AdminRepository extends CrudRepository<Admin, String> {
	
	Optional<Admin> findByUserName(String user_name);
}
