package com.ibm.employeemanager.service;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import org.apache.commons.io.FilenameUtils;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ibm.employeemanager.bean.Admin;
import com.ibm.employeemanager.bean.Employee;
//import com.ibm.employeemanager.config.AdminDetails;
import com.ibm.employeemanager.dao.AdminRepository;
import com.ibm.employeemanager.dao.EmployeeRespository;


@Service
public class EmployeeService  {
	
	@Autowired
	EmployeeRespository employeeRepository;
	@Autowired
	AdminRepository repo1;
	
	
//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		
//		Optional<Admin> user = repo1.findByUserName(username);
//		
//		user.orElseThrow(() -> new UsernameNotFoundException("User not found" + username));
//		
//		return new AdminDetails(user.get());
//	}
	
	
	public List<Admin> getUsers(){
		return (List<Admin>) repo1.findAll();
	}
	
	public Admin addAdminUser(Admin user) {
		return this.repo1.save(user);
	}
	
	public Optional<Admin> getAdminUserByName(String username) {
		return repo1.findByUserName(username);
	}
	

	



    private boolean realDataFromCsv(MultipartFile file) 
    {
        return false;
    }


    private boolean realDataFromJson(MultipartFile file) 
    {
        return false;
    }

	public List<Employee> getAllEmployees() {
		return (List<Employee>) this.employeeRepository.findAll();
	}


	public Optional<Employee> getEmployeeById(Long employeeId) {
		return this.employeeRepository.findById(employeeId);
	}

	public Employee createEmployee(Employee employee) {
		return this.employeeRepository.save(employee);
	}


	public Employee updateEmployee(Employee employeeDetails) {
		return this.employeeRepository.save(employeeDetails);
	}

	public Employee updateSkill(String skill, long id) {

		return this.employeeRepository.updateSkill(id, skill);
	}
	
	public void deleteEmployee(Employee employee) {
		this.employeeRepository.delete(employee);
	}

	public void saveExcel(Employee person) {
		employeeRepository.save(person);
		
	}

	

}
