package com.ibm.employeemanager.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;

import javax.validation.Valid;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItem;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.ibm.employeemanager.bean.Admin;
import com.ibm.employeemanager.bean.Employee;
import com.ibm.employeemanager.exception.ResourceNotFoundException;
import com.ibm.employeemanager.service.EmployeeService;



@RestController
@RequestMapping()
@CrossOrigin(origins="*")
public class EmployeeController{

	private static final Logger log = Logger.getLogger(EmployeeController.class);
	
	
	
	
	@Autowired
	EmployeeService service;
	
	@RequestMapping(method = RequestMethod.POST, value = "/login")
	@GetMapping("/login")
	boolean userLogin(@RequestBody Admin user){
		log.warn("i am in the login phase");
		boolean flag = false;
		List<Admin> users = service.getUsers();
		for(int i = 0; i < users.size(); i++) {
			if(user.getUserName().equals(users.get(i).getUserName()) && user.getPassword().equals(users.get(i).getPassword())) {
				flag = true;
			}
		}
		return flag;
		
	}

	
	@RequestMapping(method = RequestMethod.POST, value =  "/addAdminUser")
	boolean addAdminUser(@RequestBody Admin user) {
		log.info("i am in the register phase");
		Optional<Admin> users = service.getAdminUserByName(user.getUserName());
		if(users.isPresent()) {
			return false;
		}
		else {
			service.addAdminUser(user);
			return true;
		}
	}
	
	@RequestMapping(value="employees/file",method=RequestMethod.POST)
	public void saveCSVtoDb(@RequestPart("file") MultipartFile file) throws IOException  {
		log.warn("inside file save to DB");
		int sheetIdx = 0; // 0 for first sheet
//		File files = new File("/documents");
//		FileItem fileItem = new DiskFileItem("mainFile", Files.probeContentType(files.toPath()), false, files.getName(), (int) files.length(), files.getParentFile());
//
//		try {
//		    InputStream input = new FileInputStream(files);
//		    OutputStream os = fileItem.getOutputStream();
//		    IOUtils.copy(input, os);
//		    // Or faster..
////		     IOUtils.copy(new FileInputStream(file), fileItem.getOutputStream());
//		} catch (IOException ex) {
//		    // do something.
//		}
//
//		CommonsMultipartFile multipartFile = new CommonsMultipartFile(fileItem);		
//        convertSelectedSheetInXLXSFileToCSV(multipartFile, sheetIdx);
		Scanner sc=new Scanner(file.getInputStream());
		sc.nextLine();
		while(sc.hasNext()) {
			String arr[]=sc.nextLine().split(",");
			Employee person=new Employee(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5]);
			service.saveExcel(person);
			
	}
	}
	
	@GetMapping("/employees")
	public List<Employee> getAllEmployees() {
		
		log.info("i am Listing");		  
		List<Employee> employees = service.getAllEmployees();
		return employees;
	}

	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable(value = "id") Long employeeId) {
		log.warn("i am getting employee by id");
		Employee employee = service.getEmployeeById(employeeId).get();
		return ResponseEntity.ok().body(employee);
	}

	@PostMapping("/employees")
	public Employee createEmployee(@Valid @RequestBody Employee employeeDTO) {
		log.info("i am creating employee");
		return service.createEmployee(employeeDTO);
	}

	@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "id") Long employeeId,
			@Valid @RequestBody Employee employeeDetails) throws ResourceNotFoundException {
		log.debug("i am updating the db");
		Employee employee = service.getEmployeeById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + employeeId));

		employee.setEmailId(employeeDetails.getEmailId());
		employee.setLastName(employeeDetails.getLastName());
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setRole(employeeDetails.getRole());
		employee.setProjectName(employeeDetails.getProjectName());
		employee.setManagerName(employeeDetails.getManagerName());
		employee.setJobHistory(employeeDetails.getJobHistory());
		
		final Employee updatedEmployee = service.updateEmployee(employeeDetails);
		return ResponseEntity.ok(updatedEmployee);
	}
	
	@PutMapping("/employees/skill/{id}")
	public ResponseEntity<Employee> updateSkill(@PathVariable(value = "id") Long employeeId,
			@Valid @RequestBody Employee employeeDetails) throws ResourceNotFoundException {
		log.debug("skill update here");
		Employee employee = service.getEmployeeById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + employeeId));

		employee.setSkillSet(employeeDetails.getSkillSet());
		
		final Employee updatedEmployee = service.updateSkill(employee.getSkillSet(),employeeId);
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping("/employees/{id}")
	public Map<String, Boolean> deleteEmployee(@PathVariable(value = "id") Long employeeId)
			throws com.ibm.employeemanager.exception.ResourceNotFoundException {
		log.debug("i am deleting an object");
		Employee employee = service.getEmployeeById(employeeId)
				.orElseThrow(() -> new com.ibm.employeemanager.exception.ResourceNotFoundException("Employee not found for this id :: " + employeeId));
		service.deleteEmployee(employee);
		
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
	
	 private static void convertSelectedSheetInXLXSFileToCSV(File xlsxFile, int sheetIdx) throws Exception {
		 
	        FileInputStream fileInStream = new FileInputStream(xlsxFile);
	 
	        // Open the xlsx and get the requested sheet from the workbook
	        XSSFWorkbook workBook = new XSSFWorkbook(fileInStream);
	        XSSFSheet selSheet = workBook.getSheetAt(sheetIdx);
	 
	        // Iterate through all the rows in the selected sheet
	        Iterator<Row> rowIterator = selSheet.iterator();
	        while (rowIterator.hasNext()) {
	 
	            Row row = rowIterator.next();
	 
	            // Iterate through all the columns in the row and build ","
	            // separated string
	            Iterator<Cell> cellIterator = row.cellIterator();
	            StringBuffer sb = new StringBuffer();
	            while (cellIterator.hasNext()) {
	                Cell cell = cellIterator.next();
	                if (sb.length() != 0) {
	                    sb.append(",");
	                }
	                 
	                // If you are using poi 4.0 or over, change it to
	                // cell.getCellType
	                switch (cell.getCellTypeEnum()) {
	                case STRING:
	                    sb.append(cell.getStringCellValue());
	                    break;
	                case NUMERIC:
	                    sb.append(cell.getNumericCellValue());
	                    break;
	                case BOOLEAN:
	                    sb.append(cell.getBooleanCellValue());
	                    break;
	                default:
	                }
	            }
	            System.out.println(sb.toString());
	        }
	        workBook.close();
	    }

//	@RequestMapping("/viewAll")
//	List<Employee> getAllUsers(){
//		return service.getAllUsers();
//	}
//	
//	@RequestMapping(value="/employee/{id}")
//	Iterable<Employee> getUserByID(@PathVariable int id) {
//		return service.getUserbyId(id);
//	}
	
	
//	@RequestMapping(method = RequestMethod.PUT, value = "/edit/{id}")
//	public void updateEmployee(@RequestBody Employee user) {
//		service.updateEmployee(user);
//	}
	
//	@RequestMapping(method = RequestMethod.PUT, value = "/employee/edit/{id}/description/{description}")
//	void updateDescription(@PathVariable int id,@PathVariable String description) {
//		service.updateDescription(description, id);
//	}
//	
//	@RequestMapping(method = RequestMethod.PUT, value = "/employee/edit/{id}/designation/{designation}")
//	void updateDesignation(@PathVariable int id,@PathVariable String designation) {
//		service.updateDescription(designation, id);
//	}
//
//	@RequestMapping(method = RequestMethod.PUT, value = "/employee/edit/{id}/password/{password}")
//	void updatePassword(@PathVariable int id,@PathVariable String password) {
//		service.updatePassword(password, id);
//	}
	
}
