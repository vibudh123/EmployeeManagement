package com.ibm.employeemanager.exception;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ibm.employeemanager.controller.EmployeeController;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends Exception{
	private static final Logger log = Logger.getLogger(EmployeeController.class);
	private static final long serialVersionUID = 1L;

	public ResourceNotFoundException(String message){
    	super(message);
    	log.error("This is error message");
    }
}
