package com.ibm.expensemanager;

import java.util.stream.Stream;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.ibm.employeemanager.EmployeemanagerAppApplication;
import com.ibm.employeemanager.bean.Admin;
import com.ibm.employeemanager.bean.Employee;
import com.ibm.employeemanager.controller.EmployeeController;
import com.ibm.employeemanager.dao.AdminRepository;
import com.ibm.employeemanager.dao.EmployeeRespository;
import com.ibm.employeemanager.service.EmployeeService;

//@WebMvcTest(EmployeeController.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes= EmployeemanagerAppApplication.class)
class ExpenseManagerAppApplicationTests {
	
	private final static String URI = "/employees";
	
	@Autowired
	private EmployeeService service;
	
	@MockBean
	private EmployeeRespository repository;
	
	@MockBean
	private AdminRepository adminRepository;
	
	private MockMvc mockMvc;

	@Test
	public void saveAdminTest() {
		Admin user = new Admin("vibudh","sharma");
		when(adminRepository.save(user)).thenReturn(user);
		assertEquals(user, service.addAdminUser(user));
	}
	
	@Test
	public void getUsersTest() {
		when(adminRepository.findAll()).thenReturn(Stream.of(new Admin("vibudh","sharma")
				,new Admin("admin","user")).collect(Collectors.toList()));
				assertEquals(2, service.getUsers().size());
	}
	
	@Test
	public void getAllEmployeesTest() {
		when(repository.findAll()).thenReturn(Stream.of(new Employee("vibudh","sharma","abcd@gmail.com","developer","at&t","Mr. Suresh Kumar")
				,new Employee("vibudh","sharma","abcd@gmail.com","developer","at&t","Mr. Suresh Kumar")).collect(Collectors.toList()));
				assertEquals(2, service.getAllEmployees().size());
	}
	
//	@Test
//	public void getUserByIdTest() {
//		long id  = 1;
//		when(repository.findById(id))
//				.thenReturn(Stream.of(new Employee("vibudh","sharma","abcd@gmail.com","developer","at&t")).collect(Collectors.toList()));
//		assertEquals(1, service.getEmployeeById(id).size());
//	}
	
	@Test
	public void updateEmployeeTest() {
		Employee user = new Employee("vibudh","sharma","abc@gmail.com","developer","at&t","Mr. Suresh Kumar");
		when(repository.save(user)).thenReturn(user);
		assertEquals(user, service.updateEmployee(user));
	}
	
	@Test
	public void saveEmployeeTest() {
		Employee user = new Employee("vibudh","sharma","abcd@gmail.com","developer","at&t","Mr. Suresh Kumar");
		when(repository.save(user)).thenReturn(user);
		assertEquals(user, service.createEmployee(user));
	}
	
	@Test
	public void deleteUserTest() {
		Employee user = new Employee("vibudh","sharma","abcd@gmail.com","developer","at&t","Mr. Suresh Kumar");
		service.deleteEmployee(user);
		verify(repository, times(1)).delete(user);
	}
	
//	@Test
//	void testGetAllDepartments() throws Exception {
//
//		// given
//
//		Employee department = new Employee();
//
//		department.setFirstName("Vibudh");
//		department.setLastName("Sharma");
//		department.setEmailId("abcd@gmail.com");
//		department.setRole("developer");
//		department.setProjectName("at&t");
//
//		List<Employee> departments = Arrays.asList(department);
//		given(service.getAllEmployees()).willReturn(departments);
//
//		// when + then
//
//		mockMvc.perform(get(URI)).andExpect(status().isOk())
//				.andExpect(content().json("[{'firstName':'Vibudh','lastName':'Sharma','emailId':'abcd@gmail.com', 'role':'developer','projectName':'at&t'}]"));
//
//	}



}
